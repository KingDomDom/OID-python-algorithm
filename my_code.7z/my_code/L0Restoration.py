import numpy as np
from scipy.fftpack import fft2, ifft2
from utils.psf_x_otf import psf2otf


def L0Restoration(Im, kernel, _lambda, kappa=2.0):
    if kappa is None:
        kappa = 2.0

    # Pad image
    H, W = Im.shape[:2]
    Im = np.pad(Im, ((0, kernel.shape[0]-1), (0, kernel.shape[1]-1), (0, 0)), mode='wrap')

    S = Im.copy()
    betamax = 1e5
    fx = np.array([1, -1]).reshape(1, -1)    #这个地方reshape了一下
    fy = np.array([1, -1]).reshape(-1, 1)
    N, M, D = Im.shape
    sizeI2D = (N, M)
    otfFx = psf2otf(fx, sizeI2D)
    otfFy = psf2otf(fy, sizeI2D)

    KER = psf2otf(kernel, sizeI2D)
    Den_KER = np.abs(KER)**2

    Denormin2 = np.abs(otfFx)**2 + np.abs(otfFy)**2
    if D > 1:
        Denormin2 = np.tile(Denormin2, (1, 1, D))
        KER = np.tile(KER, (1, 1, D))
        Den_KER = np.tile(Den_KER, (1, 1, D))

    Normin1 = np.conj(KER) * fft2(S)

    beta = 2 * _lambda
    while beta < betamax:
        Denormin = Den_KER + beta * Denormin2
        h = np.hstack((np.diff(S, axis=1), S[:, 0:1, :] - S[:, -1:, :]))
        v = np.vstack((np.diff(S, axis=0), S[0:1, :, :] - S[-1:, :, :]))
        if D == 1:
            t = (h**2 + v**2) < _lambda / beta
        else:
            t = np.sum(h**2 + v**2, axis=2) < _lambda / beta
            t = np.tile(t, (1, 1, D))
        h[t] = 0
        v[t] = 0
        Normin2 = np.hstack((h[:, -1:, :] - h[:, 0:1, :], -np.diff(h, axis=1)))
        Normin2 = Normin2 + np.vstack((v[-1:, :, :] - v[0:1, :, :], -np.diff(v, axis=0)))
        FS = (Normin1 + beta * fft2(Normin2)) / Denormin
        S = np.real(ifft2(FS))
        beta = beta * kappa

    S = S[0:H, 0:W, :]
    return S
