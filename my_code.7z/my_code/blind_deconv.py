import numpy as np
from scipy.signal import convolve2d
from utils.adjust_psf_center import adjust_psf_center
from utils.threshold_px_py_v1 import threshold_px_py_v1
from coarse_deblur import coarse_deblur
from fine_deblur import fine_deblur
from skimage import transform

def blind_deconv(y, lambda_grad, opts):
    # gamma correct
    if opts['gamma_correct'] != 1.0:
        y = np.power(y, opts['gamma_correct'])
    
    ret = np.sqrt(0.5)
    
    #maxitr = max(int(np.floor(np.log(5/min(opts['kernel_size'])) / np.log(ret))), 0),这个地方还有问题
    #方便起见先取4
    maxitr = 4
    num_scales = maxitr + 1
    print('Maximum iteration level is', num_scales)
    
    retv = np.power(ret, np.arange(0, maxitr+1))
    k1list = np.ceil(opts['kernel_size'] * retv)
    k1list = k1list + (k1list % 2 == 0)
    k2list = np.ceil(opts['kernel_size'] * retv)
    k2list = k2list + (k2list % 2 == 0)
    
    # blind deconvolution - multiscale processing
    for s in range(num_scales, 0, -1):
        if s == num_scales:
            # at coarsest level, initialize kernel
            ks = init_kernel(k1list[s-1])
            k1 = k1list[s-1]
            k2 = k1 # always square kernel assumed
        else:
            # upsample kernel from previous level to next finer level
            k1 = k1list[s-1]
            k2 = k1 # always square kernel assumed
            
            # resize kernel from previous level
            ks = resizeKer(ks, ret, k1list[s-1], k2list[s-1])
        
        cret = retv[s-1]
        print('in blind deconv cret is:',cret)
        ys = downSmpImC(y, cret)
        print('in blind deconv ys.shape is:',ys.shape)
        print('Processing scale', s, '/', num_scales, '; kernel size', k1, 'x', k2, '; image size', ys.shape[0], 'x', ys.shape[1])
        
        # Useless operation
        if s == num_scales:
            _, _, threshold = threshold_px_py_v1(ys, max(ks.shape))
        
        if s <= 1:
            opts['xk_iter'] = opts['last_iter']
            #print(ys.shape, ks.shape)
            ks, lambda_grad, interim_latent = fine_deblur(ys, ks, lambda_grad, threshold, opts)#这里的形状有问题
        else:
            if opts['isnoisy']:
                ys = convolve2d(ys, np.ones((5, 5))/25, mode='same', boundary='symm')
                ys = ys.reshape((ys.shape[0], ys.shape[1], 1))
            ks, lambda_grad, interim_latent = coarse_deblur(ys, ks, lambda_grad, threshold, opts)
        print(ks.shape)
        ''' %% Useless operation，这是matlab代码
                if (s == num_scales)
                    [~, ~, threshold]= threshold_pxpy_v1(ys,max(size(ks)));
                end
                %-----------------------------------------------------------%
                if s <= 1
                    opts.xk_iter = opts.last_iter;
                    [ks, lambda_grad, interim_latent] = fine_deblur(ys, ks,lambda_grad, threshold, opts);
                else
                    if opts.isnoisy
                        ys = imfilter(ys,fspecial('gaussian',5,1),'same','replicate'); 
                    end
                    [ks, lambda_grad, interim_latent] = coarse_deblur(ys, ks,lambda_grad, threshold, opts);
                end'''
            
            
        
        # center the kernel
        ks = adjust_psf_center(ks)
        ks[ks < 0] = 0
        sumk = np.sum(ks)
        ks = ks / sumk
        
        # set elements below threshold to 0
        if s == 1:
            kernel = ks
            if opts['k_thresh'] > 0:
                kernel[kernel < np.max(kernel) / opts['k_thresh']] = 0
            else:
                kernel[kernel < 0] = 0
            kernel = kernel / np.sum(kernel)
    
    # end kernel estimation
    return kernel, interim_latent


def init_kernel(minsize):
    #k = np.zeros((minsize, minsize)),因为kminsize是一个浮点数，所以要转换为整数
    k = np.zeros((int(round(minsize)), int(round(minsize))))
    #k[(minsize - 1)//2, (minsize - 1)//2:(minsize - 1)//2+1] = 1/2，因为minsize是一个浮点数，所以要转换为整数
    k[int(round((minsize - 1)//2)), int(round((minsize - 1)//2)):int(round((minsize - 1)//2))+1] = 1/2
    return k

def downSmpImC(I,ret):
    downsampled = transform.rescale(I, ret, anti_aliasing=False)
    print('downsampled.shape is:',downsampled.shape)
    return downsampled
# def downSmpImC(I, ret):
#     if len(I.shape) == 2:
#         I = np.expand_dims(I, axis=-1)

#     sI = np.zeros_like(I, dtype=np.float32)

#     for ch in range(I.shape[2]):
#         img = I[:, :, ch]

#         if ret == 1:
#             sI[:, :, ch] = img.astype(np.float32)
#             continue

#         sig = 1 / np.pi * ret

#         g0 = np.arange(-50, 51, dtype=np.float32) * 2 * np.pi
#         sf = np.exp(-0.5 * g0**2 * sig**2)
#         sf = sf / np.sum(sf)
#         csf = np.cumsum(sf)
#         csf = np.minimum(csf, csf[::-1])
#         ii = np.where(csf > 0.05)[0]

#         sf = sf[ii]
#         np.sum(sf)

#         img = convolve2d(img, np.outer(sf, sf), mode='valid')

#         # 创建原始数据的网格点
#         gx, gy = np.mgrid[1:img.shape[1]+1, 1:img.shape[0]+1]

#         # 创建插值点
#         points = np.vstack((gx.ravel(), gy.ravel())).T

#         # 创建原始数据点
#         original_points = np.vstack((gx.ravel(), gy.ravel())).T

#         # 进行插值
#         sI[:, :, ch] = griddata(original_points, img.ravel(), points, method='linear')
#     print('sI.shape is:',sI.shape)
#     return sI

def resizeKer(k, ret, k1, k2):
    k = np.resize(k, (int(ret), int(ret)))
    k = np.maximum(k, 0)
    k = fixsize(k, k1, k2)
    if np.max(k) > 0:
        k = k / np.sum(k)
    return k

def fixsize(f, nk1, nk2):
    k1, k2 = f.shape
    
    while (k1 != nk1) or (k2 != nk2):
        if k1 > nk1:
            s = np.sum(f, axis=1)
            if s[0] < s[-1]:
                f = f[1:, :]
            else:
                f = f[:-1, :]
        
        if k1 < nk1:
            s = np.sum(f, axis=1)
            if s[0] < s[-1]:
                tf = np.zeros((k1+1, f.shape[1]))
                tf[:k1, :] = f
                f = tf
            else:
                tf = np.zeros((k1+1, f.shape[1]))
                tf[1:k1+1, :] = f
                f = tf
        
        if k2 > nk2:
            s = np.sum(f, axis=0)
            if s[0] < s[-1]:
                f = f[:, 1:]
            else:
                f = f[:, :-1]
        
        if k2 < nk2:
            s = np.sum(f, axis=0)
            if s[0] < s[-1]:
                tf = np.zeros((f.shape[0], k2+1))
                tf[:, :k2] = f
                f = tf
            else:
                tf = np.zeros((f.shape[0], k2+1))
                tf[:, 1:k2+1] = f
                f = tf
        
        k1, k2 = f.shape
    
    nf = f
    return nf
