import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import convolve2d
from numpy import pad
from L0Restoration import L0Restoration
from image_estimate import Image_estimate
from utils.threshold_px_py_v1 import threshold_px_py_v1
from psf_coarse import psf_coarse
from utils.bwconncomp import bwconncomp
from utils.wrap_boundary_liu import wrap_boundary_liu
from utils.opt_fft_size import opt_fft_size

def coarse_deblur(blur_B, k, lambda_grad, threshold, opts):
    # derivative filters
    dx = np.array([[-1, 1], [0, 0]])
    dy = np.array([[-1, 0], [1, 0]])
    
    H = blur_B.shape[0]
    W = blur_B.shape[1]
    #列表和元组的区别
    #blur_B_w = wrap_boundary_liu(blur_B, opt_fft_size([H, W] + [dim for dim in k.shape]))
    blur_B_w = wrap_boundary_liu(blur_B, [200, 200, 7, 7])#这里的形状有问题，先用列表替代
    print('blur_B_w.shape:', blur_B_w.shape)
    print('blur_B.shape is:',blur_B.shape)
    #这个地方的卷积必须要求输入是一个二维的
    blur_B_tmp = blur_B_w[0:H, 0:W, :].reshape((H, W))
    Bx = convolve2d(blur_B_tmp, dx, mode='same')
    By = convolve2d(blur_B_tmp, dy, mode='same')
    
    for iter in range(opts['xk_iter']):
        # L0 deblurring
        if opts['predeblur'] == 'L0':
            S = L0Restoration(blur_B, k, lambda_grad, 2.0)
        else:
            S = Image_estimate(blur_B, k, lambda_grad, 1)
        
        latent_x, latent_y, threshold = threshold_px_py_v1(S, 1, threshold)    #把max(k.shape)改为1
        print('in coarse deblur latent_x.shape:', latent_x.shape)
        print('in coarse deblur latent_y.shape:', latent_y.shape)
        print('threshold:', threshold)
        print('pruning isolated noise in kernel...')
        #这一步还存在问题，我的bwconncomp函数写的不对，先删去这一步，对结果影响不大
        # CC = bwconncomp(k, 8)
        # for ii in range(len(CC)):    #CC是什么数据类型？字典
        #     currsum = np.sum(k[CC['PixelIdxList'][ii+1]])    #索引有变化
        #     if currsum < 0.1:
        #         k[CC['PixelIdxList'][ii]] = 0
        
        k[k < 0] = 0
        k = k / np.sum(k)
        #latent的形状不知道在哪一步会变成（200，200,206），应该一直是（200,200）才对
        #这里只能先暂时取S的第一个通道
        S = S[:,:,0]

        plt.figure(1)
        S[S < 0] = 0
        S[S > 1] = 1
        plt.subplot(1, 3, 1)
        plt.imshow(blur_B, cmap='gray')
        plt.title('Blurred image')
        plt.subplot(1, 3, 2)
        plt.imshow(S, cmap='gray')
        plt.title('Interim latent image')
        plt.subplot(1, 3, 3)
        plt.imshow(k, cmap='gray')
        plt.title('Estimated kernel')
        plt.show()
    
    k[k < 0] = 0
    k = k / np.sum(k)
    
    return k, lambda_grad, S

