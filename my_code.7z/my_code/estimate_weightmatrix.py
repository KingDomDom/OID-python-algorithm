import numpy as np

def estimate_weightmatrix(blur, latent, psf, is_previous):
    alpha = 1.8e-3
    beta = 2e-4
    ww = np.ones(blur.shape)
    
    if not is_previous:
        bb = np.fft.ifft2(np.fft.fft2(latent) * np.fft.fft2(psf, s=blur.shape))
        temp = (blur - bb) ** 2
        w_matrix = 1 / (1 + np.exp((temp - alpha) / beta))
        
        # Obvious outliers
        max_blur = np.max(blur)
        min_blur = np.min(blur)
        w_matrix[blur == min_blur] = 0
        w_matrix[blur == max_blur] = 0
        
        w_matrix[w_matrix <= 0] = np.finfo(float).eps
        w_matrix[w_matrix >= 1] = 1 - np.finfo(float).eps
        
        ww = w_matrix
        ww[bb > 1] = 0
        ww[bb < 0] = 0
    
    return ww
