import numpy as np
import matplotlib.pyplot as plt
from image_estimate import Image_estimate
from psf_fine import psf_fine
from utils.bwconncomp import bwconncomp
from utils.adjust_psf_center import adjust_psf_center

def fine_deblur(blur_B, k, lambda_grad, threshold, opts):
    for iter in range(1, opts['xk_iter']+1):
        k_prev = k.copy()
        S, wi = Image_estimate(blur_B, k, lambda_grad, 0)#这里的形状有问题
        k, wk = psf_fine(blur_B, S, 5, k, threshold, 0)
        err = k_prev - k
        if np.linalg.norm(err.flatten(), 2) < 1e-3:
            break
        
        CC = bwconncomp(k, 8)
        for ii in range(CC.NumObjects):
            currsum = np.sum(k[CC.PixelIdxList[ii]])
            if currsum < 0.1:
                k[CC.PixelIdxList[ii]] = 0
        
        k[k < 0] = 0
        k = k / np.sum(k)
        
        if iter % 5 == 0:
            print(f'{iter} iterations...')
            k = adjust_psf_center(k)
            k[k < 0] = 0
            sumk = np.sum(k)
            k = k / sumk
            if opts.k_thresh > 0:
                k[k < np.max(k) / opts.k_thresh] = 0
            else:
                k[k < 0] = 0
            k = k / np.sum(k)
        
        # Visualization
        S[S < 0] = 0
        S[S > 1] = 1
        plt.subplot(2, 3, 1)
        plt.imshow(blur_B, cmap='gray')
        plt.title('Blurred image')
        plt.subplot(2, 3, 2)
        plt.imshow(S, cmap='gray')
        plt.title('Interim latent image')
        plt.subplot(2, 3, 3)
        plt.imshow(k, cmap='gray')
        plt.title('Estimated kernel')
        plt.subplot(2, 3, 4)
        plt.imshow(wi, cmap='gray')
        plt.title('Weight for image')
        plt.subplot(2, 3, 5)
        plt.imshow(wk, cmap='gray')
        plt.title('Weight for kernel')
        plt.draw()
        plt.show()

    k[k < 0] = 0
    k = k / np.sum(k)
    return k, lambda_grad, S
