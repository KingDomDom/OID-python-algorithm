import numpy as np
from scipy.signal import convolve2d
from utils.deconv_L2 import deconv_L2
from estimate_weightmatrix import estimate_weightmatrix
from utils.opt_fft_size import opt_fft_size
from utils.wrap_boundary_liu import wrap_boundary_liu


def Image_estimate(blurred, psf, reg_strength, is_previous):
    #MATLAB里面是fftw('planner', 'measure'),我不知道是干什么的，我删去了
    #MATLAB中的一个函数调用，用于设置FFTW库的计划策略。FFTW是一个计算一维n点离散傅立叶变换（DFT）的库。
    
    print('here in the image_estimate', blurred.shape[:2], psf.shape)
    # CONSTANTS for sparse priors
    w0 = 0.1
    exp_a = 0.8
    thr_e = 0.01

    # CONSTANTS for iterative reweighted least squares
    N_iters = 15
    # Finite difference filters
    dxf = np.array([[0, -1, 1]])
    dyf = np.array([[0], [-1], [1]])
    dxxf = np.array([[-1, 2, -1]])
    dyyf = np.array([[-1], [2], [-1]])
    dxyf = np.array([[-1, 1, 0], [1, -1, 0], [0, 0, 0]])

    # boundary handling
    # uses wrap_boundary_liu.. it results in a little bit faster convergence
    H, W = blurred.shape[:2]
    
    w_matrix = np.zeros(blurred.shape, dtype=np.float32)
    blurred_w = wrap_boundary_liu(blurred, [200, 200, 7, 7])#有列表和元组的区别,dim-1和dim也有区别
    blurred_w = blurred_w.astype(np.float32)
    w_matrix = wrap_boundary_liu(w_matrix, [200, 200, 7, 7])#有列表和元组的区别，dim-1和dim也有区别
    w_matrix[:H, :W, :] = 1
    # create the initial mask
    mask = np.zeros(blurred_w.shape, dtype=np.float32)
    mask[:H, :W, :] = 1
    w_matrix[(1 - mask) == 1] = 0 + np.finfo(float).eps
    w_matrix[w_matrix >= 1] = 1 - np.finfo(float).eps
    w_matrix[w_matrix <= 0] = 0 + np.finfo(float).eps
    # run IRLS
    latent_w = deconv_L2(blurred_w, blurred_w, psf, w_matrix, reg_strength)
    for iter in range(N_iters):
        w_matrix = estimate_weightmatrix(blurred_w, latent_w, psf, is_previous)
        ww = w_matrix * mask

        # compute weights for sparse priors
        dx = convolve2d(latent_w, dxf, mode='same', boundary='wrap')
        dy = convolve2d(latent_w, dyf, mode='same', boundary='wrap')
        dxx = convolve2d(latent_w, dxxf, mode='same', boundary='wrap')
        dyy = convolve2d(latent_w, dyyf, mode='same', boundary='wrap')
        dxy = convolve2d(latent_w, dxyf, mode='same', boundary='wrap')

        weight_x = w0 * np.maximum(np.abs(dx), thr_e) ** (exp_a - 2)
        weight_y = w0 * np.maximum(np.abs(dy), thr_e) ** (exp_a - 2)
        weight_xx = 0.25 * w0 * np.maximum(np.abs(dxx), thr_e) ** (exp_a - 2)
        weight_yy = 0.25 * w0 * np.maximum(np.abs(dyy), thr_e) ** (exp_a - 2)
        weight_xy = 0.25 * w0 * np.maximum(np.abs(dxy), thr_e) ** (exp_a - 2)

        # run deconvolution
        latent_w = deconv_L2(blurred_w, latent_w, psf, ww, reg_strength, weight_x, weight_y, weight_xx, weight_yy, weight_xy)

    latent = latent_w[:H, :W, :]
    w_out = ww[:H, :W, :]

    return latent, w_out
