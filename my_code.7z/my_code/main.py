import cv2
import numpy as np
from blind_deconv import blind_deconv
from image_estimate import Image_estimate

def main():
    opts = {
        'prescale': 0,  # downsampling
        'xk_iter': 4,  # the iterations
        'last_iter': 4,  # larger if image is very noisy
        'k_thresh': 20,
        'isnoisy': 1,  # filter the input for coarser scales before deblurring 0 or 1
        'kernel_size': 27,  # kernel size
        'predeblur': 'L0',  # deblurring method for coarser scales; Lp or L0
        'filename': './example.png',
        'lambda_grad': 4e-3,  # range(1e-3 - 2e-2)
        'gamma_correct': 1.0  # range (1.0-2.2)
    }

    y = cv2.imread(opts['filename'])
    #灰色和彩色图像的通道数不同
    yg = cv2.cvtColor(y, cv2.COLOR_BGR2GRAY) if y.shape[2] == 3 else y
    yg = yg.astype(np.float32) / 255.0
    print('in main the yg.shape is:',yg.shape)
    kernel, interim_latent = blind_deconv(yg, opts['lambda_grad'], opts)#这里的形状有问题

    y = y.astype(np.float32) / 255.0
    Latent = Image_estimate(y, kernel, 0.003, 0)

    cv2.imshow('Latent', Latent)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    k = kernel - np.min(kernel)
    k = k / np.max(k)
    cv2.imwrite('./kernel.png', k * 255)
    cv2.imwrite('./result.png', Latent * 255)

if __name__ == '__main__':
    main()
