import numpy as np
from scipy.fftpack import fft2, ifft2
from utils.conjgrad import conjgrad
from utils.psf_x_otf import psf2otf, otf2psf


def psf_coarse(blurred_x, blurred_y, latent_x, latent_y, weight, psf_size):
    print('latent_x.shape:', latent_x.shape)
    print('latent_y.shape:', latent_y.shape)
    print('blurred_x.shape:', blurred_x.shape)
    print('blurred_y.shape:', blurred_y.shape)
    latent_xf = fft2(latent_x)
    latent_yf = fft2(latent_y)
    blurred_xf = fft2(blurred_x)
    blurred_yf = fft2(blurred_y)
    print('latent_xf.shape:', latent_xf.shape)
    print('latent_yf.shape:', latent_yf.shape)
    print('blurred_xf.shape:', blurred_xf.shape)
    print('blurred_yf.shape:', blurred_yf.shape)

    # compute b = sum_i w_i * latent_i * blurred_i
    b_f = np.conj(latent_xf) * blurred_xf + np.conj(latent_yf) * blurred_yf
    b = np.real(ifft2(b_f))
    
    p = {}
    p['m'] = np.conj(latent_xf) * latent_xf + np.conj(latent_yf) * latent_yf
    p['img_size'] = blurred_x.shape
    p['psf_size'] = psf_size
    p['lambda'] = weight
    
    psf = np.ones(psf_size) / np.prod(psf_size)
    psf = conjgrad(psf, b, 20, 1e-5, compute_Ax, p)
    
    psf[psf < np.max(psf) * 0.05] = 0
    psf = psf / np.sum(psf)
    
    return psf

def compute_Ax(x, p):
    x_f = psf2otf(x, p['img_size'])
    y = otf2psf(p['m'] * x_f, p['psf_size'])
    y = y + p['lambda'] * x
    return y
