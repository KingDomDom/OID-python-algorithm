import numpy as np
from scipy.signal import convolve2d
from scipy.fftpack import fft2, ifft2
from utils.conjgrad import conjgrad
from utils.psf_x_otf import psf2otf, otf2psf
from utils.threshold_px_py_v1 import threshold_px_py_v1
from utils.wrap_boundary_liu import wrap_boundary_liu
from utils.opt_fft_size import opt_fft_size
from estimate_weightmatrix import estimate_weightmatrix

def psf_fine(blurred, latent, weight, psf, threshold, is_previous):
    dx = np.array([[-1, 1], [0, 0]])
    dy = np.array([[-1, 0], [1, 0]])
    H, W = blurred.shape[:2]
    blur_B_w = wrap_boundary_liu(blurred, opt_fft_size([H, W] + list(psf.shape) - 1))
    blur_B_tmp = blur_B_w[:H, :W, :]
    Bx = convolve2d(blur_B_tmp, dx, mode='valid')
    By = convolve2d(blur_B_tmp, dy, mode='valid')
    latent_x, latent_y, _ = threshold_px_py_v1(latent, max(psf.shape), threshold)
    psf_size = psf.shape

    latent_xf = fft2(latent_x)
    latent_yf = fft2(latent_y)

    for iter in range(15):
        ww_x = estimate_weightmatrix(Bx, latent_x, psf, is_previous)
        ww_y = estimate_weightmatrix(By, latent_y, psf, is_previous)

        b_f = np.conj(latent_xf) * fft2(ww_x * Bx) + np.conj(latent_yf) * fft2(ww_y * By)
        b = np.real(otf2psf(b_f, psf_size))
        p = {
            'latent_xf': latent_xf,
            'latent_yf': latent_yf,
            'img_size': Bx.shape,
            'psf_size': psf_size,
            'lambda': weight,
            'ww_x': ww_x,
            'ww_y': ww_y
        }
        psf = np.ones(psf_size) / np.prod(psf_size)
        psf = conjgrad(psf, b, 21, 1e-5, compute_Ax, p)
        psf[psf < np.max(psf) * 0.05] = 0
        psf = psf / np.sum(psf)

    w_out = ww_x
    return psf, w_out

def compute_Ax(x, p):
    x_f = psf2otf(x, p['img_size'])
    Ixconvk = p['ww_x'] * np.real(ifft2(p['latent_xf'] * x_f))
    Iyconvk = p['ww_y'] * np.real(ifft2(p['latent_yf'] * x_f))
    y = otf2psf(np.conj(p['latent_xf']) * fft2(Ixconvk) + np.conj(p['latent_yf']) * fft2(Iyconvk), p['psf_size'])
    y = y + p['lambda'] * x
    return y
