import numpy as np
from scipy.ndimage import map_coordinates

def adjust_psf_center(psf):
    X, Y = np.meshgrid(np.arange(1, psf.shape[1]+1), np.arange(1, psf.shape[0]+1))
    xc1 = np.sum(psf * X)
    yc1 = np.sum(psf * Y)
    xc2 = (psf.shape[1] + 1) / 2
    yc2 = (psf.shape[0] + 1) / 2
    xshift = np.round(xc2 - xc1)
    yshift = np.round(yc2 - yc1)
    psf = warpimage(psf, np.array([[1, 0, -xshift], [0, 1, -yshift]]))
    return psf

def warpimage(img, M):
    if img.ndim == 3:
        warped = np.zeros_like(img)
        for i in range(3):
            warped[:,:,i] = warpProjective2(img[:,:,i], M)
    else:
        warped = warpProjective2(img, M)
    warped[np.isnan(warped)] = 0
    return warped

def warpProjective2(im, A):
    if A.shape[0] > 2:
        A = A[:2, :]
    
    x, y = np.meshgrid(np.arange(1, im.shape[1]+1), np.arange(1, im.shape[0]+1))
    coords = np.vstack((x.flatten(), y.flatten()))
    homogeneousCoords = np.vstack((coords, np.ones((1, coords.shape[1]))))
    warpedCoords = np.dot(A, homogeneousCoords)
    xprime = warpedCoords[0, :] #/ warpedCoords[2, :]
    yprime = warpedCoords[1, :] #/ warpedCoords[2, :]
    
    result = map_coordinates(im, [yprime, xprime], order=1, mode='constant', cval=np.nan)
    result = result.reshape(im.shape)
    
    return result
