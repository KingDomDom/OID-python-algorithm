import numpy as np
from scipy.ndimage import label

def bwconncomp(img, connectivity=2):
    # 将图像转换为二值图像
    img = (img > 0).astype(int)
    # 计算连通组件
    labels, num = label(img, structure=np.ones((3,3)))
    # 创建一个列表，用于存储每个连通组件的像素索引
    components = []
    for i in range(1, num + 1):
        components.append(np.argwhere(labels == i))
    # 返回一个字典，包含连通组件的数量和每个连通组件的像素索引
    return {'Connectivity': connectivity, 'NumObjects': num, 'PixelIdxList': components}