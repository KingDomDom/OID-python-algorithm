from math import sqrt

def conjgrad(x, b, maxIt, tol, Ax_func, func_param, visfunc):
    r = b - Ax_func(x, func_param)
    p = r
    rsold = sum(r.flatten() * r.flatten())

    for iter in range(1, maxIt+1):
        Ap = Ax_func(p, func_param)
        alpha = rsold / sum(p.flatten() * Ap.flatten())
        x = x + alpha * p
        if 'visfunc' in locals():
            visfunc(x, iter, func_param)
        r = r - alpha * Ap
        rsnew = sum(r.flatten() * r.flatten())
        if sqrt(rsnew) < tol:
            break
        p = r + rsnew / rsold * p
        rsold = rsnew

    return x
