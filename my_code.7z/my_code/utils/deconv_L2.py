import numpy as np
from scipy.signal import fftconvolve
from utils.conjgrad import conjgrad

def deconv_L2(blurred, latent0, psf, data_we, L2_we, weight_x=None, weight_y=None, weight_xx=None, weight_yy=None, weight_xy=None):
    if weight_x is None:
        weight_x = np.ones(blurred.shape, dtype=np.float32)
        weight_y = np.ones(blurred.shape, dtype=np.float32)
        weight_xx = np.zeros(blurred.shape, dtype=np.float32)
        weight_yy = np.zeros(blurred.shape, dtype=np.float32)
        weight_xy = np.zeros(blurred.shape, dtype=np.float32)
    
    img_size = blurred.shape
    
    dxf = np.array([0, -1, 1], dtype=np.float32)
    dyf = np.array([0, -1, 1], dtype=np.float32).reshape(-1, 1)
    dyyf = np.array([-1, 2, -1], dtype=np.float32).reshape(-1, 1)
    dxxf = np.array([-1, 2, -1], dtype=np.float32)
    dxyf = np.array([[-1, 1, 0], [1, -1, 0], [0, 0, 0]], dtype=np.float32)
    
    latent = latent0.copy()
    
    psf_f = np.fft.fft2(psf, img_size)
    
    # compute b
    b = np.real(np.fft.ifft2(np.fft.fft2(data_we * blurred) * np.conj(psf_f)))
    b = b.flatten()
    
    # set x
    x = latent.flatten()
    
    # run conjugate gradient
    cg_param = {
        'psf': psf,
        'L2_we': L2_we,
        'data_we': data_we,
        'img_size': img_size,
        'psf_f': psf_f,
        'weight_x': weight_x,
        'weight_y': weight_y,
        'weight_xx': weight_xx,
        'weight_yy': weight_yy,
        'weight_xy': weight_xy,
        'dxf': dxf,
        'dyf': dyf,
        'dxxf': dxxf,
        'dyyf': dyyf,
        'dxyf': dxyf
    }
    x = conjgrad(x, b, 25, 1e-4, Ax, cg_param)
    
    latent = x.reshape(img_size)
    return latent

def Ax(x, p):
    x = x.reshape(p['img_size'])
    x_f = np.fft.fft2(x)
    y = np.real(np.fft.ifft2(np.fft.fft2(p['data_we'] * np.real(np.fft.ifft2(p['psf_f'] * x_f))) * np.conj(p['psf_f'])))
    y += p['L2_we'] * fftconvolve(p['weight_x'] * fftconvolve(x, p['dxf'], mode='same'), p['dxf'], mode='same')
    y += p['L2_we'] * fftconvolve(p['weight_y'] * fftconvolve(x, p['dyf'], mode='same'), p['dyf'], mode='same')
    y += p['L2_we'] * fftconvolve(p['weight_xx'] * fftconvolve(x, p['dxxf'], mode='same'), p['dxxf'], mode='same')
    y += p['L2_we'] * fftconvolve(p['weight_yy'] * fftconvolve(x, p['dyyf'], mode='same'), p['dyyf'], mode='same')
    y += p['L2_we'] * fftconvolve(p['weight_xy'] * fftconvolve(x, p['dxyf'], mode='same'), p['dxyf'], mode='same')
    y = y.flatten()
    return y
