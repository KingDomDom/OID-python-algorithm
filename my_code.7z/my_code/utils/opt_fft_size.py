
def opt_fft_size(n):
    # compute an optimal data length for Fourier transforms
       
    LUT_size = 4096

    opt_fft_size_LUT = None

    if opt_fft_size_LUT is None:
        print('generate opt_fft_size_LUT')
        opt_fft_size_LUT = [0] * LUT_size

        e2 = 1
        while e2 <= LUT_size:
            e3 = e2
            while e3 <= LUT_size:
                e5 = e3
                while e5 <= LUT_size:
                    e7 = e5
                    while e7 <= LUT_size:
                        if e7 <= LUT_size:
                            opt_fft_size_LUT[e7-1] = e7
                        if e7*11 <= LUT_size:
                            opt_fft_size_LUT[e7*11-1] = e7*11
                        if e7*13 <= LUT_size:
                            opt_fft_size_LUT[e7*13-1] = e7*13
                        e7 = e7 * 7
                    e5 = e5 * 5
                e3 = e3 * 3
            e2 = e2 * 2

        nn = 0
        for i in range(LUT_size-1, -1, -1):
            if opt_fft_size_LUT[i] != 0:
                nn = i
            else:
                opt_fft_size_LUT[i] = nn

    m = [0] * len(n)
    for c in range(len(n)):
        nn = n[c]
        if nn <= LUT_size:
            m[c] = opt_fft_size_LUT[nn-1]
        else:
            m[c] = -1

    return m
