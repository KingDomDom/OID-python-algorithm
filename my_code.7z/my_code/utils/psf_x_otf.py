import numpy as np
from scipy.fftpack import fftshift
from scipy.fftpack import ifftshift

def psf2otf(psf, shape):
    psf = np.pad(psf, [[0, shape[0] - psf.shape[0]], [0, shape[1] - psf.shape[1]]], mode='constant')
    for i in range(psf.ndim):
        psf = np.roll(psf, -int(psf.shape[i] / 2), axis=i)
    otf = np.fft.fftn(psf)
    otf = fftshift(otf)
    return otf

def otf2psf(otf):
    otf = ifftshift(otf)
    psf = np.fft.ifftn(otf)
    psf = np.real(psf)
    return psf
