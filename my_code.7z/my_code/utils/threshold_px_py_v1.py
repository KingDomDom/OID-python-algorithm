import numpy as np
from scipy import signal
def threshold_px_py_v1(latent, psf_size, threshold=None):
    if threshold is None:
        threshold = 0
        b_estimate_threshold = True
    else:
        b_estimate_threshold = False

    denoised = latent.copy()
    print('in threshold latent.shape:', latent.shape)
    print('in threshold denoised.shape:', denoised.shape)

    dx = np.array([[-1, 1], [0, 0]])
    dy = np.array([[-1, 0], [1, 0]])
    #二维数组的卷积
    px = signal.convolve2d(denoised, dx, mode='same')
    py = signal.convolve2d(denoised, dy, mode='same')
    print('in threshold after conv latent.shape:', latent.shape)
    print('in threshold after conv denoised.shape:', denoised.shape)
    pm = px**2 + py**2
    print('px.shape:', px.shape)
    print('py.shape:', py.shape)
    if b_estimate_threshold:
        pd = np.arctan2(py, px)
        pm_steps = np.arange(0, 2, 0.00006)
        H1 = np.flipud(np.histogram(pm[(pd >= 0) & (pd < np.pi/4)], bins=pm_steps)[0].cumsum())
        H2 = np.flipud(np.histogram(pm[(pd >= np.pi/4) & (pd < np.pi/2)], bins=pm_steps)[0].cumsum())
        H3 = np.flipud(np.histogram(pm[(pd >= -np.pi/4) & (pd < 0)], bins=pm_steps)[0].cumsum())
        H4 = np.flipud(np.histogram(pm[(pd >= -np.pi/2) & (pd < -np.pi/4)], bins=pm_steps)[0].cumsum())

        th = max(np.max(psf_size) * 20, 10)

        for t in range(len(pm_steps)):
            min_h = min(H1[t], H2[t], H3[t], H4[t])
            if min_h >= th:
                threshold = pm_steps[-t+1]
                break

    m = pm < threshold
    while np.all(m):
        threshold *= 0.81
        m = pm < threshold
    px[m] = 0
    py[m] = 0

    if b_estimate_threshold:
        threshold = threshold
    else:
        threshold /= 1.1

    return px, py, threshold