import numpy as np
from scipy.fftpack import idst, dst
'''这个函数的目的是通过在图像的边界添加额外的像素，并使这些像素的值平滑过渡，
   来减少图像边界的突变，从而在进行频域处理时减少边界效应。'''

def wrap_boundary_liu(img, img_size):
    #Ch = img.shape[2],有形状的问题
    #Ch = 1
    H, W, Ch = img.shape
    print('in wrap_boundary,the H W Ch:',H, W, Ch)
    print('in wrap_boundary,the img_size:',img_size[0], img_size[1], img_size[2], img_size[3])
    #这个地方也根据实际情况进行了修改
    H_w = img_size[2] 
    W_w = img_size[3] 
    print('in wrap_boundary,the H_w W_w:',H_w, W_w)
    ret = np.zeros((img_size[0]+H_w, img_size[1]+W_w, Ch))
    for ch in range(0,Ch):
        alpha = 1    #这简直是我的天才之笔，如果看不懂可以来问我
        left_bdry = alpha - 1    #alpha
        right_bdry = -alpha    #end-alpha+1
        HG = img[:, :, ch]
        #下面是下标置换，左闭右开，需要左边界加1和右边界减1
        r_A = np.zeros((alpha*2+H_w, W))
        r_A[0:left_bdry+1, :] = HG[right_bdry:, :]
        r_A[right_bdry:, :] = HG[0:left_bdry+1, :]
        a = ((np.arange(H_w)-1)/(H_w-1))
        r_A[left_bdry+1:right_bdry, 0] = (1-a)*r_A[left_bdry-1, 0] + a*r_A[right_bdry, 0]
        r_A[left_bdry+1:right_bdry, -1] = (1-a)*r_A[left_bdry-1, -1] + a*r_A[right_bdry, -1]

        A2 = solve_min_laplacian(r_A[left_bdry:right_bdry-1, :])
        r_A[left_bdry:right_bdry-1, :] = A2
        A = r_A

        r_B = np.zeros((H, alpha*2+W_w))
        r_B[:, 0:left_bdry+1] = HG[:, right_bdry:]
        r_B[:, right_bdry:] = HG[:, 0:left_bdry+1]
        a = ((np.arange(W_w)-1)/(W_w-1))
        r_B[0, left_bdry:right_bdry-1] = (1-a)*r_B[0, left_bdry] + a*r_B[0, right_bdry]    #
        r_B[-1, left_bdry:right_bdry-1] = (1-a)*r_B[-1, left_bdry] + a*r_B[-1, right_bdry]    #

        B2 = solve_min_laplacian(r_B[:, left_bdry:right_bdry-1])
        r_B[:, left_bdry:right_bdry-1] = B2     #matlab中是三维的
        B = r_B

        r_C = np.zeros((alpha*2+H_w, alpha*2+W_w))    #这个地方也进行了修改
        r_C[0:left_bdry+1, :] = B[right_bdry:, :]
        r_C[right_bdry:, :] = B[0:left_bdry+1, :]
        r_C[:, 0:alpha] = A[:, -alpha:]
        r_C[:, right_bdry:] = A[:, 0:left_bdry+1]

        C2 = solve_min_laplacian(r_C[left_bdry:right_bdry-1, left_bdry:right_bdry-1])
        r_C[left_bdry:right_bdry-1, left_bdry:right_bdry-1] = C2
        C = r_C

        A = A[left_bdry:right_bdry-1, :]#
        B = B[:, left_bdry+1:right_bdry]#
        C = C[left_bdry+1:right_bdry, left_bdry:right_bdry-1]#
        print('A.shape,B.shape,C.shape:',A.shape, B.shape, C.shape)
        # 首先，我们沿着第二个轴（列）连接 img[:,:,ch] 和 B
        top = np.concatenate((img[:,:,ch], B), axis=1)

        # 然后，我们沿着第二个轴（列）连接 A 和 C
        bottom = np.concatenate((A, C), axis=1)

        # 最后，我们沿着第一个轴（行）连接 top 和 bottom
        ret[:,:,ch] = np.concatenate((top, bottom), axis=0)

    return ret


def solve_min_laplacian(boundary_image):
    H, W = boundary_image.shape
    print(H, W)
    f = np.zeros((H, W))

    boundary_image[1:-2, 1:-2] = 0
    #把索引-1删去了，不然boundary_image[:,:-1]的形状一直是0，799，而boundary_image的形状是0,800
    #j = 2:H-1;      k = 2:W-1;      f_bp = zeros(H,W);
    #f_bp(j,k) = -4*boundary_image(j,k) + boundary_image(j,k+1) + boundary_image(j,k-1) + boundary_image(j-1,k) + boundary_image(j+1,k);
    f_bp = -4*boundary_image[1:-1,1:-1] + boundary_image[1:-1, 2:] + boundary_image[1:-1, 0:-2] + boundary_image[0:-2, 1:-1] + boundary_image[2:, 1:-1]

    f1 = np.zeros((H, W))

    f1[1:-1, 1:-1] = f[1:-1,1:-1] - f_bp

    f2 = f1[1:-1, 1:-1]
    tt = dst(f2)
    f2sin = dst(tt.T).T

    x, y = np.meshgrid(np.arange(1, W-1), np.arange(1, H-1))
    denom = (2*np.cos(np.pi*x/(W-1))-2) + (2*np.cos(np.pi*y/(H-1)) - 2)

    f3 = f2sin / denom

    tt = idst(f3)
    img_tt = idst(tt.T).T

    img_direct = boundary_image.copy()
    img_direct[1:-1, 1:-1] = 0
    img_direct[1:-1, 1:-1] = img_tt

    return img_direct

'''
def solve_min_laplacian(boundary_image):
    # 确保 boundary_image 的形状至少为 (1, n)
    if boundary_image.shape[0] == 0:
        boundary_image = np.expand_dims(boundary_image, axis=0)

    h, w = boundary_image.shape
    f_bp = -4*boundary_image
    if w > 1:
        f_bp += np.pad(boundary_image[:, 1:], ((0, 0), (0, 1)))  # right
        f_bp += np.pad(boundary_image[:, :-1], ((0, 0), (1, 0)))  # left
    if h > 1:
        f_bp += np.pad(boundary_image[1:, :], ((0, 1), (0, 0)))  # down
        f_bp += np.pad(boundary_image[:-1, :], ((1, 0), (0, 0)))  # up

    return f_bp
'''